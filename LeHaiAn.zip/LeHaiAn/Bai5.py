CN = float(input("Nhập cân nặng(kg): "))
CC = float(input("Nhập chiều cao(m): "))
BMI = CN / (CC ** 2)
print(f"Chỉ số BMI của bạn là: {BMI}")
if BMI < 18.5:
    print("Gay")
elif BMI < 25:
    print("Bình thường")
elif BMI < 30:
    print("Thừa cân")
else:
    print("Béo phì")
