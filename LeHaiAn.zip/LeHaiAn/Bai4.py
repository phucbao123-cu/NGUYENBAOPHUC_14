DIEM = float(input("Nhập điểm số: "))
if 8.5 <= DIEM < 10:
    print("Xếp hạng A")
elif 7 <= DIEM < 8.5:
    print("Xếp hạng B")
elif 5 <= DIEM < 7:
    print("Xếp hạng C")
else:
    print("Xếp hạng D")
