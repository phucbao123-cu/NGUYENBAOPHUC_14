N = int(input("Nhập tuổi: "))
if N < 12:
    print("Trẻ em")
elif N < 18:
    print("Thiếu niên")
elif N < 60:
    print("Người trưởng thành")
else:
    print("Người cao tuổi")
